# Aurora🕸️
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

- Description: Aurora is Linux Penetration Testing Tool for Scanning Networks. 
               First script is to discover all devices on your network.
               Second script is automation script for NMAP (tool for network discovery and security auditing).

## Requirements
- Python 3.x
```bash
$ pip install -r requirements.txt
```

## Installation
```bash
# clone the repo
$ git clone https://github.com/radojicic23/aurora.git

# change the working directory to aurora
$ cd aurora

# install the requirements
$ python3 -m pip install -r requirements.txt
```

## Run
```bash
$ sudo python3 main.py
```

## Disclaimer⚠️
THIS TOOL IS FOR EDUCATIONAL PURPOSES ONLY. DO NOT USE AGAINST ANY NETWORK THAT YOU DON'T OWN OR HAVE AUTHORIZATION TO TEST!
